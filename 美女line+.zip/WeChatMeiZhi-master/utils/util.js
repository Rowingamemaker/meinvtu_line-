// 工具类
var BASE_URL = "https://xxx.com";//你的域名
var GET_MEIZHI_URL = BASE_URL.concat("/meizitu/public/api/");

function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}
function toOtherXCX() {
  console.log('toOtherXCX')
  var targetPage = '/portal/lists/tourl';
  var _this = this;
  wx.request({
    url: GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    success: function (res) {
      console.log(res)
      if (res.statusCode != '404') {
        var appid = res.data.appid;
        wx.navigateToMiniProgram({
          appId: appid,
          success(res) {
            wx.hideNavigationBarLoading();
            wx.hideLoading();
          }
        })
      } else {
        wx.hideNavigationBarLoading();
        wx.hideLoading();
        wx.setNavigationBarTitle({
          title: '商城'
        })
        wx.showModal({
          title: '提示',
          content: '商城暂未开放,敬请期待',
          showCancel: false,
        })
      }
    },
    fail: function () {
      console.log('fail')
      wx.hideNavigationBarLoading();
      wx.hideLoading();
      wx.showModal({
        title: '提示',
        content: '商城暂未开放,敬请期待',
        showCancel: false,
      })
    }
  });
}
function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}
/**
 * 请求数据
 * @param that Page的对象，用来setData更新数据
 * @param targetPage 请求的目标页码
 */


// 将方法、变量暴露出去
module.exports = {
  BASE_URL: BASE_URL,
  GET_MEIZHI_URL: GET_MEIZHI_URL,
  formatTime: formatTime,
  toOtherXCX: toOtherXCX
}
