// pages/shangcheng/shangcheng.js
var Constant = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.showLoading({
      title: '跳转商城中',
    })
    wx.showNavigationBarLoading();
    wx.setNavigationBarTitle({
      title: '跳转商城中'
    })
    Constant.toOtherXCX();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    wx.setNavigationBarTitle({
      title: '商城'
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function requestData(that, targetPage) {
  wx.request({
    url: Constant.GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    success: function (res) {
      // console.log(res.data.data.list)
      var arr = res.data.data.list;
      // var number = [];
      // for (var i = 0; i < arr.length; i++) {
      //   console.log('循环');
      //   console.log(res.data.data.list[i].more.photos)
      //   var photos = res.data.data.list[i].more.photos;
      //   number[i] = photos.length;
      // }
      // console.log(number);
      if (res.data.code == 1) {
        that.setData({
          items: arr,
        })
      }
    }
  });
}