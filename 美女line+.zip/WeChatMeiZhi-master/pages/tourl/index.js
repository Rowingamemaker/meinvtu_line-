//index.js
//获取应用实例
var app = getApp()
var Constant = require('../../utils/util.js');
Page({
  data: {
    items: [],
    hidden: true,
    loading: false,
    loadmorehidden: true,
    plain: false
  },

  onItemClick: function (e) {
    var id = e.currentTarget.dataset.id;
    var targetUrl = "/pages/list/list?id=";
    wx.navigateTo({
      url: targetUrl + id
    });
  },
  toOtherXCX: function () {
    Constant.toOtherXCX();
  },
  loadMore: function (event) {
    var that = this
    requestData(that, mCurrentPage + 1);
  },

  onLoad: function (e) {
    var title = e.name;
    var id = e.id;
    wx.setNavigationBarTitle({ title: title })
    var url = "portal/lists/getCategoryPostLists/category_id/" + id;
    requestData(this, url);
  },
  onShareAppMessage: function () {

  }
})

function requestData(that, targetPage) {
  wx.request({
    url: Constant.GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    success: function (res) {
      console.log(res)
      var arr = res.data.data.list;
      if (res.data.code == 1) {
        that.setData({
          items: arr
        })
      }
    }
  });
}