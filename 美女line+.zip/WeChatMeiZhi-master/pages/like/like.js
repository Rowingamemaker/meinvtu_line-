//index.js
//获取应用实例
var app = getApp()
var Constant = require('../../utils/util.js');
Page({
  data: {
    items: [],
    hidden: true,
    loading: false,
    loadmorehidden: true,
    plain: false
  },
  onItemClick: function (e) {
    var id = e.currentTarget.dataset.id;
    var targetUrl = "/pages/list/list?id=" + id;
    wx.navigateTo({
      url: targetUrl
    });
  },
  loadMore: function (event) {
    var that = this
    requestData(that, mCurrentPage + 1);
  },

  onLoad: function () {
    console.log('onLoad')
    // var likeStore = wx.getStorageSync('likearr');
    // for (var i = 0; i < likeStore.length; i++) {
    //   console.log(likeStore[i])
    //   var url = "portal/articles/read/id/" + likeStore[i];
    //   requestData(this, url);
    // }
  },
  onShareAppMessage: function () {

  },
  onShow: function () {
    var likeStore = wx.getStorageSync('likearr');
    this.setData({
      items: []
    })
    for (var i = 0; i < likeStore.length; i++) {
      var url = "portal/articles/read/id/" + likeStore[i];
      requestData(this, url);
    }
  }
})

function requestData(that, targetPage) {
  wx.request({
    url: Constant.GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    success: function (res) {

      console.log(res.data.data)
      var arr = that.data.items;
      arr.push(res.data.data);
      if (res.data.code == 1) {
        that.setData({
          items: arr,
        })
      }
    }
  });
}