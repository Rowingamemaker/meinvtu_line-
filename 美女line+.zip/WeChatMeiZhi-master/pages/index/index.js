//index.js
//获取应用实例
var app = getApp()
var Constant = require('../../utils/util.js');
Page({
  data: {
    items: [],
    hidden: true,
    loading: false,
    loadmorehidden: true,
    plain: false,
    page: 1,//分页的位置
    pageNumber: 10,//每页的数量
    flag: true,//如果没图片了 则为false就不让加载了
    hidden: false
  },
  onItemClick: function (e) {
    var id = e.currentTarget.dataset.id;
    var targetUrl = "/pages/list/list?id=";
    wx.navigateTo({
      url: targetUrl + id
    });
  },

  onLoad: function () {
    
    var url = "portal/lists/recommendedPage";
    var page = this.data.page;
    var pageNumber = this.data.pageNumber;
    requestData(this, url, page, pageNumber);
  },
  onPullDownRefresh: function () {
    var url = "portal/lists/recommendedPage";
    var page = this.data.page;
    var pageNumber = this.data.pageNumber;
    requestData(this, url, page, pageNumber);
  },
  onReachBottom: function () {
    console.log('onReachBottom');
    var flag = this.data.flag;
    var url = "portal/lists/recommendedPage"
    var page = this.data.page;
    var pageNumber = this.data.pageNumber;
    var that = this;
    if (flag) {
      wx.showLoading({
        title: '加载更多中',
        success: function () {
          that.setData({
            flag: false
          })
          pageNumber = pageNumber + 10;
          requestData(that, url, page, pageNumber);
        }
      })
      setTimeout(function () {
        wx.hideLoading();
      }, 1000);

    } else {
      wx.showLoading({
        title: '都加载完啦~~',
      })
      setTimeout(function () {
        wx.hideLoading()
      }, 1000);
    }
  },
  toOtherXCX: function () {
    Constant.toOtherXCX();
  },
  onShareAppMessage: function () {

  },
  loading: function () {
  }
})

function requestData(that, targetPage, a, b) {
  that.setData({
    page: a,
    pageNumber: b
  })
  wx.request({
    url: Constant.GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    data: {
      a: a,
      b: b
    },
    success: function (res) {
      var arr = res.data.data.list;
      // arr.reverse();
      if (arr.length % 10 == 0) {
        that.setData({
          flag: true
        })
      }
      if (res.data.code == 1) {
        var items = that.data.items;
        items.push(arr);
        that.setData({
          items: arr,
          hidden: true
        })
      }
    },
    complete: function (res) {
      wx.stopPullDownRefresh()
      if (wx.hideLoading) {
        wx.hideLoading();
      }
    }
  });
}