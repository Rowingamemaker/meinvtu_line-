var app = getApp()
Page({
  data: {
    motto: 'Hello World',
    userInfo: {}
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //调用应用实例的方法获取全局数据  
    app.getUserInfo(function (userInfo) {
      //更新数据  
      that.setData({
        userInfo: userInfo
      })
    })
  },
  like: function () {
    wx.navigateTo({
      url: '../like/like',
    })
  },
  toOtherXCX: function () {
    Constant.toOtherXCX();
  },
  share: function () {
    this.onShareAppMessage();
  },
  onShareAppMessage: function (res) {
    console.log('ee')
    return {
      title: '美女line+',
      path: '/page/index/index',
      success: function (res) {
        // 转发成功
        console.log('转发成功')
      },
      fail: function (res) {
        // 转发失败
        console.log('转发失败')
      }
    }
  }
})  