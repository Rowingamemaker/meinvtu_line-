// pages/list/list.js
var Constant = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    arr: [],
    id: '',
    likeImg: true,
    hidden: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var likeStore = wx.getStorageSync('likearr');
    var id = parseInt(options.id);
    var url = "portal/articles/read/id/" + id;
    requestData(this, url)
    if (!notInArr(likeStore, id)) {
      this.setData({
        id: id,
        likeImg: false
      })
    } else {
      this.setData({
        id: id,
      })
    }

  },
  max: function (e) {
    // var img = e.currentTarget.dataset.img;
    var img = this.data.arr;
    img = arrToArr(img, 'url');
    wx.previewImage({
      current: e.currentTarget.dataset.img,
      urls: img,
    })
  },
  like: function (e) {
    var id = parseInt(e.currentTarget.dataset.id);
    console.log(typeof (id));
    var likearr = [];
    var likeStore = wx.getStorageSync('likearr');
    var i = likeStore.length;
    if (this.data.likeImg) {
      //变成喜欢
      this.setData({
        likeImg: false
      })
      if ((likeStore.length != 0) && notInArr(likeStore, id)) {
        if (i >= 0) {
          likeStore[i] = id;
          wx.setStorageSync('likearr', likeStore)
        }
      } else if (likeStore.length == 0) {
        likearr[0] = id;
        wx.setStorageSync('likearr', likearr)
      }
    } else {
      this.setData({
        likeImg: true
      })
      removeByValue(likeStore, id);
      wx.setStorageSync('likearr', likeStore);
    }
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function notInArr(arr, index) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] == index) {
      return false;
    }
  }
  return true;
}
function arrToArr(arr, index) {
  var returnArr = [];
  for (var i = 0; i < arr.length; i++) {
    returnArr[i] = arr[i][index];
  }
  return returnArr;
}
function removeByValue(arr, val) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] == val) {
      arr.splice(i, 1);
      break;
    }
  }
}
function requestData(that, targetPage) {
  wx.request({
    url: Constant.GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    success: function (res) {
      var arr = res.data.data.more.photos;
      var title = res.data.data.post_title;
      var keywords = res.data.data.post_keywords;
      var cao = '';
      var mabi = [];
      var j = 0;
      for (var i = 0; i < keywords.length; i++) {
        if (keywords[i] != ',') {
          cao += keywords[i];
          if ((i + 1) == keywords.length) {
            mabi[j] = cao;
            cao = '';
            j++;
          }
        } else if (keywords[i] == ',') {
          mabi[j] = cao;
          cao = '';
          j++;
        }
      }
      var date = res.data.data.update_time;
      if (res.data.code == 1) {
        that.setData({
          arr: arr,
          title: title,
          keywords: keywords,
          date: date,
          mabi: mabi,
          hidden: true
        })
      }
    }
  });
}