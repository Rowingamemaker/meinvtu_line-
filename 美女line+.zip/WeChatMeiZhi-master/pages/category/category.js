// pages/category/category.js
var Constant = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    arr: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(Constant)
    requestData(this, 'portal/categories')
  },
  toUrl: function (e) {
    console.log(e.currentTarget.dataset.id);
    var id = e.currentTarget.dataset.id;
    var name = e.currentTarget.dataset.name;
    wx.navigateTo({
      url: '../tourl/index?id=' + id + '&name=' + name,
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  toOtherXCX: function () {
    Constant.toOtherXCX();
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function requestData(that, targetPage) {
  wx.request({
    url: Constant.GET_MEIZHI_URL + targetPage,
    header: {
      "Content-Type": "application/json"
    },
    success: function (res) {
      console.log(res)
      var arr = res.data.data;
      if (res.data.code == 1) {
        that.setData({
          arr: arr
        })
      }
    }
  });
}